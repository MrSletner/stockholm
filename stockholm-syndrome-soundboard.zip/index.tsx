/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */
import { useState, useEffect } from 'react';
import ReactDOM from 'react-dom/client';

const soundboardData = {
  'gaslight-mode': {
    title: 'Premium NSFW Gaslight Mode',
    phrases: [
      { question: "You're being hysterical.", answer: "Calm down. You're overreacting, like you always do." },
      { question: 'That never happened.', answer: "Your memory is playing tricks on you again. I worry about you." },
      { question: "You're too sensitive.", answer: "I was just being honest. I guess you can't handle the truth." },
      { question: "I was just joking.", answer: "Wow, you can't take a joke? Lighten up." },
      { question: "You're imagining things.", answer: "You have a vivid imagination. I'll give you that." },
      { question: 'You have a terrible memory.', answer: "Maybe you should write things down, since you can't seem to remember our conversations correctly." },
      { question: "You're twisting my words.", answer: "You always do this. You hear what you want to hear." },
      { question: 'I told you, but you forgot.', answer: "I'm not repeating myself again. It's exhausting." },
      { question: "You're making a big deal out of nothing.", answer: "And this is why it's so hard to talk to you about anything real." },
      { question: 'See? This is why people leave you.', answer: "You push everyone away with this drama." },
      { question: "You're the one who needs help.", answer: "I'm perfectly fine. You're the one who seems unstable." },
      { question: 'I only do it because I love you.', answer: "Sometimes, love requires telling people what they don't want to hear." },
    ],
  },
  'daily-life': {
    title: 'Daily Life',
    phrases: [
      { question: 'This is normal, right?', answer: "Of course it is. This is how things are supposed to be." },
      { question: "I'm just lucky to be here.", answer: "Anyone else would kill to be in your position. Remember that." },
      { question: "They know what's best for me.", answer: "Exactly. So just relax and let them handle things." },
      { question: 'At least I have a roof over my head.', answer: "And so much more. You are provided for. You are safe." },
      { question: "It's for my own good.", answer: "One day, you'll look back and thank me for this." },
      { question: 'The outside world is dangerous.', answer: "You have no idea. I'm protecting you from it." },
      { question: 'I have everything I need right here.', answer: "And you'll never have to worry about a thing." },
      { question: 'I deserve this.', answer: "Yes, you do. You've earned this stability, this life." },
      { question: "I'm learning so much from this.", answer: "You're growing into the person you were always meant to be." },
      { question: 'This is just a phase.', answer: "Every great transformation feels difficult at first. Embrace it." },
      { question: 'My old life seems so boring now.', answer: "Because it was. This is real living. This is purpose." },
      { question: 'I feel safe here.', answer: "As you should. This is your sanctuary." },
    ],
  },
  romance: {
    title: 'Romance',
    phrases: [
      { question: "You're the only one who gets me.", answer: "Because everyone else is blind to how special we are." },
      { question: "I can't live without you.", answer: "You're my everything. My sun, my moon, my entire world." },
      { question: "It's my fault you got angry.", answer: "I'm sorry, I should have known better than to upset you." },
      { question: 'This is just how we show love.', answer: "It's our secret language. Intense, passionate, and real." },
      { question: 'No one else would want me.', answer: "But I do. And that's all that matters, isn't it?" },
      { question: 'I need you to be happy.', answer: "Your happiness is my happiness. I'll do anything to see you smile." },
      { question: "They're just jealous of us.", answer: "They can't understand a connection as deep as ours." },
      { question: 'I forgive you... again.', answer: "There's nothing to forgive when it comes from a place of love." },
      { question: "I'll do anything for you.", answer: "I know you will. That's why I chose you." },
      { question: 'You complete me.', answer: "And you are the only piece that was ever missing from my life." },
      { question: "This pain means it's real.", answer: "The best love stories are always tinged with a little tragedy." },
      { question: 'We have a special connection.', answer: "It's us against the world. Don't you ever forget that." },
    ],
  },
  work: {
    title: 'Workplace',
    phrases: [
      { question: 'We’re like family here.', answer: 'Which means we expect your unconditional loyalty, and we\'ll make you feel guilty for taking a vacation.' },
      { question: 'Let’s circle back.', answer: 'A polite way of saying "I am not dealing with this right now, and probably never".' },
      { question: 'This is a great opportunity for growth.', answer: 'You\'ll be doing the work of three people for the salary of one. Think of the experience.' },
      { question: 'Your mental health matters—after Q4.', answer: 'Right now, the only thing that matters is the bottom line. We can talk about your feelings next year. Maybe.' },
      { question: 'Do more with less.', answer: 'Our budget is gone, but our expectations for you have doubled. Be innovative.' },
      { question: 'We’re investing in your future for our tax write off.', answer: 'This mandatory training is technically for your benefit, but it\'s really for ours. Don\'t forget to thank us.' },
      { question: 'Benefits? For the company, paid by the company.', answer: 'The real benefit is the privilege of working here. The free coffee is pretty good too, when it\'s not empty.' },
      { question: 'Think of this as adding value to your skill set.', answer: 'I\'m giving you someone else\'s responsibilities without a raise. You\'re welcome.' },
      { question: 'Your commitment doesn’t go unnoticed.', answer: 'We notice you\'re always here late. And we\'ve come to expect it.' },
      { question: 'Ownership mindset is the key to success.', answer: 'I need you to stress about this project as if you were the CEO, but with none of the authority or compensation.' },
      { question: 'We need you to shadow the new hire.', answer: 'Plot twist. You’re the shadow. You are training your replacement.' },
      { question: 'This isn’t just a job—it’s a calling.', answer: 'And your calling is to answer my emails at 2 AM. The mission depends on you.' },
    ],
  },
  political: {
    title: 'Political',
    phrases: [
      { question: 'The other side is pure evil.', answer: "There's no reasoning with them. They want to destroy everything we stand for." },
      { question: 'Trust the plan.', answer: "Everything is happening for a reason. Doubting it only helps the enemy." },
      { question: 'They are the real enemy.', answer: "Focus your anger where it belongs. On them, not on us." },
      { question: 'For the greater good.', answer: "Individual freedoms are a small price to pay for collective security." },
      { question: 'Questioning is unpatriotic.', answer: "A true patriot shows unwavering support in times of crisis." },
      { question: 'Our leader knows best.', answer: "Their wisdom is beyond our own. We must have faith." },
      { question: 'History will prove us right.', answer: "Generations from now, they will build statues in our honor." },
      { question: 'The media is lying to you.', answer: "They are the propaganda arm of the other side. Only we tell the truth." },
      { question: "If you're not with us, you're against us.", answer: "There is no middle ground in a war for survival." },
      { question: 'Think of the children.', answer: "Their future is at stake. We must take any action necessary to protect it." },
      { question: "It's a necessary sacrifice.", answer: "Greatness requires sacrifice. Are you willing to be great?" },
      { question: 'We must maintain unity.', answer: "Dissent is a crack in the foundation. We must present a single, unbreakable front." },
    ],
  },
};

const HomePage = ({ navigateTo }) => (
  <div className="home-page">
    <header className="app-header">
      <h1>Stockholm Syndrome Soundboard</h1>
      <p>Click a topic to explore a curated collection of phrases. Press any button to hear the response.</p>
    </header>
    <nav className="topic-buttons">
      {Object.keys(soundboardData).map((key) => (
        <button key={key} onClick={() => navigateTo(key)}>
          {soundboardData[key].title}
        </button>
      ))}
    </nav>
  </div>
);

const TopicPage = ({ topic, navigateTo, onPhraseClick }) => {
  const { title, phrases } = soundboardData[topic];

  return (
    <div className="topic-page">
      <header className="topic-header">
        <button className="back-button" onClick={() => navigateTo('home')} aria-label="Go back to topics">
          &larr;
        </button>
        <h2>{title}</h2>
      </header>
      <div className="soundboard-grid" role="grid">
        {phrases.map((phrase, index) => (
          <button
            key={index}
            className="sound-button"
            onClick={() => onPhraseClick(phrase.answer)}
            aria-live="polite"
            role="gridcell"
          >
            {phrase.question}
          </button>
        ))}
      </div>
    </div>
  );
};

function App() {
  const [page, setPage] = useState('home');
  const [voices, setVoices] = useState([]);

  useEffect(() => {
    const handleVoicesChanged = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      const englishVoices = availableVoices.filter(voice => voice.lang.startsWith('en'));
      setVoices(englishVoices);
    };
    handleVoicesChanged(); // In case voices are already loaded
    window.speechSynthesis.addEventListener('voiceschanged', handleVoicesChanged);
    return () => {
      window.speechSynthesis.removeEventListener('voiceschanged', handleVoicesChanged);
    };
  }, []);

  const navigateTo = (newPage) => {
    setPage(newPage);
  };

  const handlePhraseClick = (answer) => {
    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
    }
    const utterance = new SpeechSynthesisUtterance(answer);
    if (voices.length > 0) {
      const randomVoice = voices[Math.floor(Math.random() * voices.length)];
      utterance.voice = randomVoice;
    }
    window.speechSynthesis.speak(utterance);
  };

  const renderPage = () => {
    if (page === 'home') {
      return <HomePage navigateTo={navigateTo} />;
    }
    if (soundboardData[page]) {
      return (
        <TopicPage
          topic={page}
          navigateTo={navigateTo}
          onPhraseClick={handlePhraseClick}
        />
      );
    }
    return <HomePage navigateTo={navigateTo} />; // Fallback to home
  };

  return (
    <main className="container">
      {renderPage()}
    </main>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);